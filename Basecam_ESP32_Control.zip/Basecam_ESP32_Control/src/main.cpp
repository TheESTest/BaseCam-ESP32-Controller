/* Elation Sports Technologies
Austin Allen
22 Jun 2024

Basecam ESP32 Control Code

This code is for an ESP32 connected via RX1,TX1 pins
to the Basecam controller. There are 2 x options for running
the code:
A) There is only 1 x ESP32, and it is connected to both 3 x joysticks
and the BaseCam controller.
B) There are 2 x ESP32s - the Client/Master ESP32, which reads from the
3 x joysticks and sends the data wirelessly over BLE, and the Peripheral/Slave
ESP32, which receives the sent signal data and then relays it to the BaseCam
controller.

For Case (A), set the BLE_Mode_boolean varible to false.

For Case (B), set the BLE_Mode_boolean variable to true. In this case, the
Client/Master ESP32 is running the following Arduino code:
BaseCam_ESP32_BLE_Client.ino

The Peripheral/slave ESP32 is running this PlatformIO project code
in order to utilize the most up-to-date Basecam Serial API.
The code is modified from the MimicControl Arduiuno example on
the BaseCam Github:
https://github.com/basecamelectronics/sbgc32-serial-api/tree/master/examples/Arduino/MimicControl

The Client/Master ESP32 constantly reads joystick values values and
sends them out over BLE. That ESP32 is running this Arduino script:
BaseCam_ESP32_BLE_Client.ino

The RX and TX pin definitions, as well the pin definitions for
joysticks #1, #2, and #3 are in the file app.h

*/

#include "app.h"

//These libraries are used for wireless BLE control.
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>

// These definitions are used for BLE control.
// Define UUIDs for service and characteristic
// These need to be matched in the Client ESP32's code.
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

//Set the variable BLE_Mode_boolean to false if you're only using 1 x ESP32 to talk
//directly to the BaseCam controller.
//Set this variable to true if you're using 2 x ESP32 boards, and this
//board is receiving data over Bluetooth Low Energy (BLE), to be relayed
//to the BaseCam controller.
bool BLE_Mode_boolean = true;


/* ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ */
/*   					Global Software Objects  					  */
/* __________________________________________________________________ */

			GeneralSBGC_t			SBGC32_Device;

static 		Control_t    			Control;
static		ControlConfig_t			ControlConfig;

			InputsInfo_t			InputsInfo;

static		i16 servoOut [8] = {	SERVO_OUT_DISABLED, SERVO_OUT_DISABLED,
									SERVO_OUT_DISABLED, SERVO_OUT_DISABLED,
									SERVO_OUT_DISABLED, SERVO_OUT_DISABLED,
									SERVO_OUT_DISABLED, SERVO_OUT_DISABLED};

static		AverageValue_t JoystickAverage [2];

static		ui32 currentTime;
static 		ui32 lastControlTime = 0;
static 		ui32 lastButtonTime;

static		AdjVarGeneral_t			AdjVarGeneral [6];

//Placeholders
int val1 = 0;
int val2 = 0;
int val3 = 0;

//Initial placeholder values
int initial_x = 0;
int initial_y = 0;
int initial_z = 0;

//Direct connection factor to make the sent values smaller
float joystick_division_factor = 0.05;

//Defined globally here so the RX1,TX1 pins on the ESP32-S3 DevKitM (different
//pins than the DevKitC board) define the SBGC connection
HardwareSerial mySerial(1); // Use a hardware serial port

typedef struct {
    int value1;
    int value2;
	int value3;
} ThreeValues;

// Structure containing initial placeholder values
ThreeValues threeValues = {0, 0, 0};


// BLE function
// Callback class for the characteristic, i.e. this is what the
// ESP32 will do when it receives (stuff) over BLE
// Callback class for the characteristics
class MyCallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
        std::string value = pCharacteristic->getValue();
		// Print the received value for debugging
        DEBUG_SERIAL_PORT.println("Received data: " + String(value.c_str()));
        if (value.length() > 0) {
			// Parse the string to fill the ThreeValues structure
			sscanf(value.c_str(), "%d,%d,%d", &threeValues.value1, &threeValues.value2, &threeValues.value3);
		}
	}
};

void setup()
{
	//Specify the pins on the ESP32 that are connected to the BaseCam controller
	//for serial connection. The RX and TX pin definitions are in the file app.h
    SBGC_SERIAL_PORT.begin(SBGC_SERIAL_SPEED, SERIAL_8N1, RX_PIN, TX_PIN);

	//Define the serial debugging stream of output, e.g. connect this ESP32
	//to a computer and check the Serial Monitor to see feedback printed out
	//by this ESP32.
	DEBUG_SERIAL_PORT.begin(DEBUG_SERIAL_SPEED);

	//Direct connection
	if (BLE_Mode_boolean == false){
		initial_x = int(float(analogRead(JOY_X_ANALOG_PIN)) * joystick_division_factor);
		initial_y = int(float(analogRead(JOY_Y_ANALOG_PIN)) * joystick_division_factor);
		initial_z = int(float(analogRead(JOY_Z_ANALOG_PIN)) * joystick_division_factor);
	}

	/* SimpleBGC32 Init */
	SBGC32_Init(&SBGC32_Device);

	//BLE
	if (BLE_Mode_boolean == true){
		// Create the BLE Device
		BLEDevice::init("ESP32_S3_BLE");
		// Create the BLE Server
		BLEServer *pServer = BLEDevice::createServer();
		// Create the BLE Service
		BLEService *pService = pServer->createService(SERVICE_UUID);
		// Create a BLE Characteristic
		BLECharacteristic *pCharacteristic = pService->createCharacteristic(
											CHARACTERISTIC_UUID,
											BLECharacteristic::PROPERTY_READ |
											BLECharacteristic::PROPERTY_WRITE
											);
		// Assign the callback to the characteristic
		pCharacteristic->setCallbacks(new MyCallbacks());
		// Start the service
		pService->start();
		// Start advertising
		pServer->getAdvertising()->start();
	}

	/* Control Configurations */
	//If you wanted, you could set the control mode for pitch, yaw and roll
	//to be by angle instead of by speed.
	Control.controlMode[PITCH] = CtrlM_MODE_SPEED;
	Control.controlMode[YAW] = CtrlM_MODE_SPEED;
	Control.controlMode[ROLL] = CtrlM_MODE_SPEED;

	//Populate the Control structure with some initial values.
	Control.AxisC[PITCH].speed = threeValues.value1;
	Control.AxisC[YAW].speed = threeValues.value2;
	Control.AxisC[ROLL].speed = threeValues.value3;

	ControlConfig.flags = RTCCF_CONTROL_CONFIG_FLAG_NO_CONFIRM;

	//Optional - for fitering and averaging the joystick values over time.
	AverageInit(&JoystickAverage[0], LOW_PASS_FACTOR);
	AverageInit(&JoystickAverage[1], LOW_PASS_FACTOR);
	AverageInit(&JoystickAverage[2], LOW_PASS_FACTOR);

	/*  - - - - - - - - - Initializing commands - - - - - - - - - - - */
	SBGC32_ControlConfig(&SBGC32_Device, &ControlConfig);
	SBGC32_SetServoOut(&SBGC32_Device, servoOut);

	DEBUG_SERIAL_PORT.println("Initialization complete!");
	delay(1500);

	/*  = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */
}

void loop()
{
	/* Getting current time */
	currentTime = SBGC32_Device.GetTimeFunc(SBGC32_Device.Drv);

	//Put the values of the joysticks into the threeValues structure every N
	//number of microseconds as defined by CMD_CONTROL_DELAY in app.h, for
	//example, every 20 msec.
	if ((currentTime - lastControlTime ) > CMD_CONTROL_DELAY)
	{
		lastControlTime = currentTime;

		//BLE
		//Populate the Control structure with the latest values in the threeValues
		//structure, which gets continuously updated by the BLE callback class
		if (BLE_Mode_boolean == true){
			int val1 = int(float(threeValues.value1 * joystick_division_factor));
			int val2 = int(float(threeValues.value2 * joystick_division_factor));
			int val3 = int(float(threeValues.value3 * joystick_division_factor));
			Control.AxisC[PITCH].speed = val1;
			Control.AxisC[YAW].speed = val2;
			Control.AxisC[ROLL].speed = val3;
		}

		//Direct connection
		//Update the Control structure with values read directly from the 3 x joysticks
		//using the analogRead() function.
		if (BLE_Mode_boolean == false){
			int val1 = int(float(analogRead(JOY_X_ANALOG_PIN)) * joystick_division_factor) - initial_x;
			int val2 = int(float(analogRead(JOY_Y_ANALOG_PIN)) * joystick_division_factor) - initial_y;
			int val3 = int(float(analogRead(JOY_Z_ANALOG_PIN)) * joystick_division_factor) - initial_z;
			Control.AxisC[PITCH].speed = val1;
			Control.AxisC[YAW].speed = val2;
			Control.AxisC[ROLL].speed = val3;
		}

		//DEBUG_SERIAL_PORT.println(String(val1) + "," + String(val2) + "," + String(val3));

		//Update the Basecame controller by sending it the updated Control structure.
		SBGC32_Control(&SBGC32_Device, &Control);

		/* SBGC32_CheckConfirmation(&SBGC32_Device, CMD_CONTROL); */
	}

	/* Make a constant sampling time by inserting a delay of 1 ms */
	while ((SBGC32_Device.GetTimeFunc(SBGC32_Device.Drv) - currentTime) < 1);

}
